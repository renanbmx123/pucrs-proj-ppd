/* const.h (Roland Teodorowitsch; 30 ago. 2013 - 31 mar. 2017) */

#define NOTASPROG	0x20000000LU
#define NOTASVERS	1
#define OBTEM_NOTA	1

